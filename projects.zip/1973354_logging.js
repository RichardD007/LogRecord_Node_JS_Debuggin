module.exports.a  ="1973354 Richard Donato";
module.exports.b  ="Creating Log Records of a Node.js file. \n";

